const inputEl = document.querySelector('input');
const buttonEl = document.querySelector('button');
const timerEl = document.querySelector('span');

// Напишите реализацию createTimerAnimator
// который будет анимировать timerEl
const createTimerAnimator = () => {
  return (seconds) => {
    let timer = setInterval(function () {

      let secondsTimer = seconds % 60 // Получаем секунды
      let minutes = seconds / 60 % 60 // Получаем минуты
      let hours = seconds / 60 / 60 % 60 // Получаем часы
      // Условие если время закончилось то...
      if (seconds <= 0) {
        // Таймер удаляется
        clearInterval(timer);
        // Выводит сообщение что время закончилось
        alert("Time is up");
      } else { // Иначе
        // Создаём строку с выводом времени
        let strTimer = `${Math.trunc(hours)}:${Math.trunc(minutes)}:${secondsTimer}`;
        // Выводим строку в блок для показа таймера
        timerEl.innerHTML = strTimer;
      }
      --seconds; // Уменьшаем таймер
    }, 1000)
  };
};

const animateTimer = createTimerAnimator();

inputEl.addEventListener('input', (e) => {
  // Очистите input так, чтобы в значении
  // оставались только числа
  e.target.value = e.target.value.replace(/[^\d.]/g, '');
});

buttonEl.addEventListener('click', () => {
  const seconds = Number(inputEl.value);

  animateTimer(seconds);

  inputEl.value = '';
});
